# Studio Link onAir - Linux LV2 VoIP/AoIP Plugin

## Install/Update

Download newest "studio-link-linux.tar.gz" from https://github.com/Studio-Link-v2/backend/releases

```
$ tar -xzf studio-link-linux.tar.gz
$ mkdir -p ~/.lv2/studio-link.lv2
$ cp -a lv2-plugin/* ~/.lv2/studio-link.lv2/
```
